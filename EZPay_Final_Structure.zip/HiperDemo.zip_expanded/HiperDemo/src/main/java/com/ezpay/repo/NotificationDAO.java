package com.ezpay.repo;

import com.ezpay.model.Notification;
import com.ezpay.util.HibernateUtil;

import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.List;

public class NotificationDAO {

    public void save(Notification notification) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            session.save(notification);
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
    }

    public Notification findById(Long id) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Notification notification = null;
        try {
            notification = session.get(Notification.class, id);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
        return notification;
    }

    public List<Notification> findAll() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        List<Notification> notifications = null;
        try {
            notifications = session.createQuery("from Notification", Notification.class).list();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
        return notifications;
    }

    public void update(Notification notification) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            session.update(notification);
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
    }

    public void delete(Long id) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            Notification notification = session.get(Notification.class, id);
            if (notification != null) {
                session.delete(notification);
            }
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
    }
}
