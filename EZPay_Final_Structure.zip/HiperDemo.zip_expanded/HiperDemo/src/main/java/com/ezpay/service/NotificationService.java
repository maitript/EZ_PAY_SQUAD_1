package com.ezpay.service;

import com.ezpay.model.Notification;
import com.ezpay.model.Payment;
import com.ezpay.model.User;
import com.ezpay.repo.NotificationDAO;

import java.util.Date;
import java.util.Scanner;

public class NotificationService {

    private NotificationDAO notificationDAO;

    public NotificationService() {
        this.notificationDAO = new NotificationDAO();
    }

    public void sendPaymentNotification(Payment payment) {
        Notification senderNotification = new Notification();
        senderNotification.setSenderId(payment.getSender().getUserId());
        senderNotification.setReceiverId(payment.getReceiver().getUserId());
        senderNotification.setPaymentId(payment.getPaymentId());
        senderNotification.setMessage(payment.getSender().getUsername() + " your payment of " + payment.getAmount() + " was successful.");
        senderNotification.setPaymentDate(new Date());
        senderNotification.setAmount(payment.getAmount());
        senderNotification.setStatus(payment.getStatus());
        System.out.println("The payment id is: " + senderNotification.getPaymentId());
        System.out.println("Sender: "+ payment.getSender().getUsername());
        System.out.println("Receiver: "+ payment.getReceiver().getUsername());
        System.out.println("Transaction completed at: " +senderNotification.getPaymentDate());
        notificationDAO.save(senderNotification);
    }

    public void getNotification(Long id) {
        Notification notif = notificationDAO.findById(id);
        System.out.println(notif);
    }

    public void deleteNotification(Long id) {
        notificationDAO.delete(id);
        System.out.println("Notification deleted successfully");
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter sender details (username,email,phone) separated by commas:");
        String senderInput = scanner.nextLine();
        System.out.println("Enter receiver details (username,email,phone) separated by commas:");
        String receiverInput = scanner.nextLine();

        String[] senderDetails = senderInput.split(",");
        String[] receiverDetails = receiverInput.split(",");

        User sender = new User(123L, senderDetails[0], senderDetails[1], senderDetails[2]);
        User receiver = new User(111L, receiverDetails[0], receiverDetails[1], receiverDetails[2]);

        System.out.println("Enter the amount for the payment:");
        double amount = scanner.nextDouble();
        
    
        Payment pay = new Payment(123L, amount, new Date(), "Successful", sender, receiver);
        

        NotificationService service = new NotificationService();
        service.sendPaymentNotification(pay);

        // Optional: Uncomment if needed
        // service.getNotification(pay.getPaymentId());
        // service.deleteNotification(pay.getPaymentId());

        scanner.close();
    }
}
