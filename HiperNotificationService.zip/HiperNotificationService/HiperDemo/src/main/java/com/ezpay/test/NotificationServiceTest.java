package com.ezpay.test;

import org.junit.Before;
import org.junit.Test;

import com.ezpay.model.Notification;
import com.ezpay.model.Payment;
import com.ezpay.model.User;
import com.ezpay.repo.NotificationDAO;
import com.ezpay.service.NotificationService;

import static org.junit.Assert.*;

import java.util.Date;


	
	import org.junit.After;
	
	import static org.junit.Assert.*;

	import java.util.Date;

	public class NotificationServiceTest {
	    private NotificationService notificationService;
	    private NotificationDAO notificationDAO;

	    @Before
	    public void setUp() {
	        // Initialize the DAO and service
	       
	        notificationService = new NotificationService();
	    }

	    @After
	    public void tearDown() {
	        // Clean up the database entries to avoid side effects
	        // This could involve deleting notifications created during tests
	    	User sender = new User(123L, "senderName", "sender@example.com", "1234567890");
	        User receiver = new User(456L, "receiverName", "receiver@example.com", "0987654321");
	        Payment payment = new Payment(345678L, 4235.9, new Date(), "Successful", sender, receiver);
	        notificationDAO=new NotificationDAO();
	        notificationDAO.delete(payment.getPaymentId());

	    	
	    }

	    @Test
	    public void testSendPaymentNotification() {
	        // Arrange
	        User sender = new User(123L, "senderName", "sender@example.com", "1234567890");
	        User receiver = new User(456L, "receiverName", "receiver@example.com", "0987654321");
	        Payment payment = new Payment(345678L, 4235.9, new Date(), "Successful", sender, receiver);

	        // Act
	        notificationService.sendPaymentNotification(payment);

	        // Assert
	        notificationDAO=new NotificationDAO();
	        
	        Notification result = notificationDAO.findById(payment.getPaymentId());
	        assertNotNull("Notification should be created", result);
	        assertEquals("Message should match expected output",
	                     "senderName your payment of 4235.9 was successful.",
	                     result.getMessage());
	    
	}

}
