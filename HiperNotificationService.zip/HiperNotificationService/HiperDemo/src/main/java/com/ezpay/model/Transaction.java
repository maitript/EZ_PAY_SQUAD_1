package com.ezpay.model;

import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "transaction_table")
public class Transaction {

    @Id
    @Column(name = "transaction_id", nullable = false, length = 255)
    private String transactionId;

    @Column(name = "sender_account_id", length = 255)
    private String senderAccountId;

    @Column(name = "receiver_account_id", length = 255)
    private String receiverAccountId;

    @Column(name = "transaction_type", length = 50)
    private String transactionType;

    @Column(name = "amount", precision = 15, scale = 2)
    private double amount;

    @Column(name = "timestamp")
    private Timestamp timestamp;

    @Column(name = "transaction_status", length = 50)
    private String transactionStatus;

    @Column(name = "label_description", length = 255)
    private String labelDescription;

    @Column(name = "payment_method", length = 50)
    private String paymentMethod;

    // Getters and Setters
}
